class _AppData:
    appConfig = None

import sys
sys.modules[__name__]=_AppData()