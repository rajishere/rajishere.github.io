import base64
import sys

from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_v1_5
import Constants

class Decoder(object):
    
    def decode(self, inputText):
        decodedText = ""
        try:
    #        print("reading key file")

            # read key file
            with open(Constants.appRoot + 'assets/private_key.pem') as f:
                key_text = f.read()
            
            # create a private key object
            privateKey = RSA.importKey(key_text)
    #        print("creating cipher")
            # create a cipher object
            cipher = PKCS1_v1_5.new(privateKey)
    #        print("decode from base64")
            # decode base64
            cipher_text = base64.b64decode(inputText)
    #        print("decrypting")
            # decrypt
            plain_text = cipher.decrypt(cipher_text, None)

            decodedText = plain_text.decode('utf-8').strip()
        except Exception as e:
            return decodedText
#            print(e)
        return decodedText
