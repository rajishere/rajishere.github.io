import json
import pickle
from datetime import datetime
import os
import time

datestring = datetime.strftime(datetime.now(), '%Y-%m-%d')
fileName = '/home/pi/Documents/scan-and-pay-validation/logs/log_'+datestring+'.p'
if os.path.exists(fileName) == False:
    pickle.dump( [], open( fileName, "wb" ) )
existingLogs = pickle.load( open( fileName, "rb" ) )
for item in existingLogs:
    print(item)