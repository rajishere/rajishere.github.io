import json
from collections import namedtuple

class AppInfo(object):
    def __init__(self):
        with open('Info.json') as f:
            data = f.read()
            self.data = json.loads(data, object_hook=lambda d: namedtuple('X', d.keys())(*d.values()))
        return