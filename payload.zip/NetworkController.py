from Order import Order
import websocket
import Constants
import ssl

class NetworkController(object):

    def sendOrderData(self, order, successhandler, errorhandler):

        try:

            #order = Order("blahblah", 37126, 0.0, True, True)
            finalURL = Constants.webSocketURL.replace("%@", order.data["totem_id"])
            #print(finalURL)
            #ws = create_connection(finalURL, headers={"Authorization": "Totem f7a7e0540ceffe823f18329ff286a408b0071287"})
            ws = websocket.WebSocket(sslopt={"cert_reqs": ssl.CERT_NONE})
            ws.connect(finalURL, http_proxy_host="sproxy.sgtm.7-11.com", http_proxy_port="3128")
            #print "Sent"
            #print "Receiving..."
            result =  ws.recv()
            print "Received '%s'" % result

            print("Sending 'Order info'...")
            print(order.toJSON())
            ws.send(order.toJSON())

            ws.close()
        except Exception as e:
            print(e)
            errorhandler("Error sending server input")
        successhandler()
        return
