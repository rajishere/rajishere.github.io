class _Constants:
    class ConstantsError(TypeError): pass
    def __setattr__(self, name, value):
        if self.__dict__.has__key(name):
            raise self.ConstantsError, "Can't rebind const(%s)"%name
        self.__dict__[name]=value
        
    appRoot = "/home/pi/Documents/scan-and-pay-validation/"
    
    updateInfoURL = "https://rajishere.github.io/info.json"
    updatePayloadURL = "https://rajishere.github.io/payload.zip"
    
    # Network
    webSocketURL = "wss://api.7-eleven.com/ws/totem/%@/"
    
    # Totem
    storeId = "37126"
    totemId = "37126_1"
    
    version = "1.1"
    
    # Launch
    updateRequired = "Updated required"

    # LED
    defaultColorR = 255
    defaultColorG = 255
    defaultColorB = 255
    
    # Rules
    allowedAmount= 3000
    allowedTime = 60 * 20
    
import sys
sys.modules[__name__]=_Constants()
