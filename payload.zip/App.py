from UpdateController import UpdateController


uc = UpdateController()
if uc.hasUpdates():
    uc.downloadPackage()