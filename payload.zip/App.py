import sys
from AppConfigController import AppConfigController
from QRcodeScanner import QRcodeScanner
#from ZBarQRCodeReader import ZBarQRCodeReader
import Constants
import AppData
from Decoder import Decoder
from OrderController import OrderController
from LEDController import LEDController
from Order import Order
from NetworkController import NetworkController
from Logger import Logger
#from AudioController import AudioController
from UpdateController import UpdateController

# Global constants for app
version = "1.0"
qrcodeScanner = None
orderController = OrderController()
ledController = LEDController()
#zbarQRCodeReader = ZBarQRCodeReader()
networkController = NetworkController()
logger = Logger()
#audioController = AudioController()

def stopAndCleanUp():
    ledController.stop()
    #qrcodeScanner.stop()
    return

def sendToServer(payload, orderValidated, isValidOrder):
    def networkSuccess():
        return
    def networkError(message):
        print(message)
        return
    order = Order(payload, orderValidated, isValidOrder)
    networkController.sendOrderData(order, networkSuccess, networkError)
    return

def verifyScanInput(payload):
    print("Verify payload: "+ payload)
    def verifyScanInputSuccess():
        ledController.showSuccess()
        #audioController.playSuccess()
        sendToServer(payload, True, True)
        return
    def verifyScanInputError(message):
        print("error", message)
        ledController.showError()
        #audioController.playError()
        return
    orderController.verifyScanInput(payload, verifyScanInputSuccess, verifyScanInputError)
    return

def setUpScanner():
    def startScannerSuccess(inputText):
        #print(multiprocessing.current_process().name)
        #raw_input('')
        if AppData.appConfig.enableScanDecoding == 1:
            decodedText = Decoder().decode(inputText)
            verifyScanInput(decodedText)
            logger.logPayload(inputText, decodedText)
            return
        verifyScanInput(inputText)
        logger.logPayload("", inputText)
        return
    def startScannerError():
        print("QRcode Error")
        return

    ledController.start()

    qrcodeScanner = QRcodeScanner()
    qrcodeScanner.startScanner(startScannerSuccess, startScannerError)
    #zbarQRCodeReader.start(startScannerSuccess, startScannerError)
    return

def appMain():
    global version
    def fetch_app_config_success(appConfig):
        AppData.appConfig = appConfig
        if len(appConfig.warningMessage) > 0:
            print(appConfig.warningMessage)
        if (version in appConfig.appVersions) == False:
            print(Constants.updateRequired)
            return
        try:
            setUpScanner()
        except KeyboardInterrupt:
            # stop all and clean up
            stopAndCleanUp()
        return

    def fetch_app_config_error(message):
        print(message)
        return
    
    updateController = UpdateController()
    if updateController.hasUpdates():
        updateController.downloadPackage()
    #AppConfigController().fetchAppConfig(fetch_app_config_success, fetch_app_config_error)
    return

if len(sys.argv) > 0 and 'stop' in sys.argv:
    # stop as recieved from command line
    stopAndCleanUp()
else:
    # start the main script
    appMain()
