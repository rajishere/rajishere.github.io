import serial

class QRcodeScanner(object):
    scannerSerial = None
    def startScanner(self, scanHandler, errorhandler):
        global scannerSerial
        scannerSerial = serial.Serial(
            port='/dev/ttyACM0',\
            baudrate=115200,\
            parity=serial.PARITY_NONE,\
            stopbits=serial.STOPBITS_ONE,\
            bytesize=serial.EIGHTBITS,\
            timeout=0)
        if scannerSerial.isOpen():
            print("Port already open, restarting...")
            scannerSerial.close()
            scannerSerial.open()
        while True:
            inputText = scannerSerial.readline()
            if inputText:
                scanHandler(inputText)
        return