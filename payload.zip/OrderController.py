import json
from collections import namedtuple
import AppData
import time
import Constants
    

class OrderController(object):
    
    def verifyScanInput(self, payload, successhandler, errorhandler):
        try:
            barcodeData = json.loads(payload, object_hook=lambda d: namedtuple('X', d.keys())(*d.values()))
        except ValueError as e:
            errorhandler("Incorrect json")
        else:
            if barcodeData:
                barcodeDictionary = barcodeData._asdict()
                if 'v' in barcodeDictionary:
                    if barcodeData.v == AppData.appConfig.qrcodeVersion:
                        if 'tAmt' in barcodeDictionary and barcodeData.tAmt <= Constants.allowedAmount:
                            if 'cdt' in barcodeDictionary:
                                cdt = 0.0
                                try:
                                    cdt = float(barcodeData.cdt)
                                except:
                                    errorhandler("Invalid Time")
                                    cdt = 0.0
                                if cdt == 0.0:
                                    errorhandler("Invalid Time")
                                else:
                                    if (float(barcodeData.cdt) + (Constants.allowedTime)) > time.time():
                                        if 'sId' in barcodeDictionary and barcodeData.sId == Constants.storeId:
                                            successhandler()
                                        else:
                                            errorhandler("Invalid Store Id")
                                    else:
                                        errorhandler("Invalid Time")
                            else:
                                errorhandler("Invalid Time")
                        else:
                            errorhandler("Invalid Amount")
                    else:
                        errorhandler("Incorrect QR code version")
                else:
                    errorhandler("No version key in json")
            else:
                errorhandler("Empty json")
        return