import serial

ser = serial.Serial(
    port='/dev/ttyACM0',\
    baudrate=115200,\
    parity=serial.PARITY_NONE,\
    stopbits=serial.STOPBITS_ONE,\
    bytesize=serial.EIGHTBITS,\
    timeout=0)
print("connected to: " + ser.portstr)
if ser.isOpen():
    print("Port already open, restarting...")
    ser.close()
    ser.open()

while True:
    line = ser.readline()
    if line:
        print(line)
