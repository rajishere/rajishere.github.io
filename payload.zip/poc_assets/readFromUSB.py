import sys
import usb.core
import usb.util

device = usb.core.find(idVendor=0x2dd6, idProduct=0x26e1)

if device is None:
    raise ValueError('Device not found')

if device.is_kernel_driver_active(0):
    try:
        device.detach_kernel_driver(0)
    except usb.core.USBError as e:
        print("Could not detach kernal driver: %s" % str(e))

try:
    device.set_configuration()
    device.reset()
except usb.core.USBError as e:
    print("Could not set configuration: %s" % str(e))
    
endpoint = device[0][(0, 0)][0]

while 0:
    try:
        data = device.read(endpoint.bEndpointAddress, endpoint.wMaxPacketSize)
        print(data)
        print(str(unichr(data[2])))
    except usb.core.USBError as e:
            if e.errno == 110:
                continue
            else:
                print("error: %s" % e)
                break

usb.util.release_interface(device, 0)

device.attach_kernel_driver(0)