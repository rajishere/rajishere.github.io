#!/usr/bin/python
from sys import argv
import zbar
from threading import Thread

class ZBarQRcodeScanner(Thread):
    scanHandler = None
    errorhandler = None
    
    def __init__(self):
        Thread.__init__(self)
        self.running = True
    
    def run(self):
        global scanHandler
        global errorhandler
        try:
            # create a Processor
            self.proc = zbar.Processor()

            # configure the Processor
            self.proc.parse_config('enable')

            # initialize the Processor
            device = '/dev/video0'
            self.proc.init(device)

            # setup a callback
            def my_handler(proc, image, closure):
                # extract results
                for symbol in image:
                    # do something useful with results
                    print 'Detected: %s' % symbol.data
                    scanHandler(symbol.data)
                    break

            self.proc.set_data_handler(my_handler)

            # enable the preview window
        # Hide the preview window after testing
            self.proc.visible = True

            # initiate scanning
            self.proc.active = True

            while self.running:
                self.proc.user_wait()
            
            self.proc.active = False
        except:
            errorhandler()
	return
    
    def stop(self):
        self.running = False
        
    def setHandlers(self, successHandler, failurehandler):
        global scanHandler
        global errorhandler
        scanHandler = successHandler
        errorhandler = failurehandler   
        return
    
    def stop():
        self.proc.active = False
        return
