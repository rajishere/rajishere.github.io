import RPi.GPIO as GPIO
from neopixel import *
import time
import json
from threading import Thread
import multiprocessing
from multiprocessing import Process, Value
import serial

# Neo Pixel
# LED strip configuration:
LED_COUNT      = 24      # Number of LED pixels.
LED_PIN        = 18      # GPIO pin connected to the pixels (18 uses PWM!).
#LED_PIN        = 10      # GPIO pin connected to the pixels (10 uses SPI /dev/spidev0.0).
LED_FREQ_HZ    = 800000  # LED signal frequency in hertz (usually 800khz)
LED_DMA        = 10      # DMA channel to use for generating signal (try 10)
LED_BRIGHTNESS = 255     # Set to 0 for darkest and 255 for brightest
LED_INVERT     = False   # True to invert the signal (when using NPN transistor level shift)
LED_CHANNEL    = 0       # set to '1' for GPIOs 13, 19, 41, 45 or 53

def colorWipe(strip, color, wait_ms=50):
    """Wipe color across display a pixel at a time."""
    for i in range(strip.numPixels()):
        strip.setPixelColor(i, color)
        strip.show()
        time.sleep(wait_ms/1000.0)
    return

waitPeriod = Value('i' ,10)
# 0 for default, 1 for green, 2 for red
presentColorState = Value('i' ,0)
successErrorCounter = Value('i' ,0)
lightProcess = None

def showPresentLightState(strip, presentColorState, waitPeriod, successErrorCounter):
    while True:
        print('color state: %d' % presentColorState.value)
        print('wait state: %d' % waitPeriod.value)
        print('successErrorCounter state: %d' % successErrorCounter.value)
        color = Color(255, 255, 255)
        if presentColorState.value == 1:
            color = Color(255, 0, 0)
            successErrorCounter.value += 1
        elif presentColorState.value == 2:
            color = Color(0, 255, 0)
            successErrorCounter.value += 1
        
        for i in range(strip.numPixels()):
            strip.setPixelColor(i, color)

        if presentColorState.value == 2:
            for j in range(0, 255, 5):
                strip.setBrightness(j)
                strip.show()
                time.sleep(waitPeriod.value/1000.0)
            for k in range(255, 0, -5):
                strip.setBrightness(k)
                strip.show()
                time.sleep(waitPeriod.value/1000.0)            
        else:
            for j in range(0, 255):
                strip.setBrightness(j)
                strip.show()
                time.sleep(waitPeriod.value/1000.0)
            for k in range(255, 0, -1):
                strip.setBrightness(k)
                strip.show()
                time.sleep(waitPeriod.value/1000.0)
        
        if presentColorState.value == 1 and successErrorCounter.value != 0 and successErrorCounter.value > 2:
            successErrorCounter.value = 0
            waitPeriod.value = 10
            presentColorState.value = 0
        elif successErrorCounter.value != 0 and successErrorCounter.value > 8:
            successErrorCounter.value = 0
            waitPeriod.value = 10
            presentColorState.value = 0
    return

def setupLight(strip):
    global waitPeriod
    global presentColorState
    global successErrorCounter
    global lightProcess
    lightProcess = multiprocessing.Process(target=showPresentLightState, args=(strip, presentColorState, waitPeriod, successErrorCounter))
    lightProcess.start()
    return

def showSuccess(strip):
    global waitPeriod
    global presentColorState
    waitPeriod.value = 5
    presentColorState.value = 1
    return

def showError(strip):
    global waitPeriod
    global presentColorState
    waitPeriod.value = 1
    presentColorState.value = 2
    return

# App globals
scanInProgress = False

def processInput(barcodeText):
    global scanInProgress
    if scanInProgress:
        # Ignore
        print('A scan is already in progress')
        return
    scanInProgress = True
    
    if not barcodeText:
        showError(strip)
    else:
        barcodeData = {}
        try:
            barcodeData = json.loads(barcodeText)
        except ValueError as e:
            showError(strip)
        else:
            if isinstance(barcodeData, dict):
                if 'v' in barcodeData:
                    showSuccess(strip)
                else:
                    showError(strip)
            else:
                showError(strip)
    scanInProgress = False
    return

# App Start
ser = serial.Serial(
    port='/dev/ttyACM0',\
    baudrate=115200,\
    parity=serial.PARITY_NONE,\
    stopbits=serial.STOPBITS_ONE,\
    bytesize=serial.EIGHTBITS,\
    timeout=0)
print("connected to: " + ser.portstr)
if ser.isOpen():
    print("Port already open, restarting...")
    ser.close()
    ser.open()
# Create NeoPixel object with appropriate configuration.
strip = Adafruit_NeoPixel(LED_COUNT, LED_PIN, LED_FREQ_HZ, LED_DMA, LED_INVERT, LED_BRIGHTNESS, LED_CHANNEL)
# Intialize the library (must be called once before other functions).
strip.begin()
setupLight(strip)
print  ("Barcode reader started...Type n to exit")
try:
    while True:
        barcodeText = ser.readline()
        if barcodeText:
            print(barcodeText)
            if barcodeText == 'n':
                break
            processInput(barcodeText)
            #        t = Thread(target=processInput, args=(barcodeText,))
            #        t.start()
finally:
    lightProcess.terminate()
    colorWipe(strip, Color(0,0,0), 10)
    ser.close()

colorWipe(strip, Color(0,0,0), 10)
ser.close()
#end of file
