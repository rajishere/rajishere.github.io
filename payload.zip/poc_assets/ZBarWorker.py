#!/usr/bin/python
import zbar

def zbarWorker(successHandler, errorHandler):
    # create a Processor
    proc = zbar.Processor()

    # configure the Processor
    proc.parse_config('enable')

    # initialize the Processor
    device = '/dev/video0'
    proc.init(device)

    # setup a callback
    def my_handler(proc, image, closure):
        # extract results
        for symbol in image:
            # do something useful with results
            #print 'Detected: %s' % symbol.data
            successHandler(symbol.data)
            break

    proc.set_data_handler(my_handler)

    # enable the preview window
    # Hide the preview window after testing
    proc.visible = True

    # initiate scanning
    proc.active = True
    try:
        proc.user_wait()
    except Exception as e:
        print(e)
        errorHandler()
    return
    