
from Crypto.Cipher import AES

key = "MIGfMA0GCSqGSIb3"
decipher = AES.new(key, AES.MODE_ECB)
decipher.decrypt("bdNgAbFkF+ejvLlIIdzDZC0RmI9OQTMp1mJtYy52jJDoQ3JVj4NNmYolfKRVbpWWTxenXT5ouL0tP4rJj1a+Am1NjmX25apNbHZPKv4/hLX/0VKhPf4yNmL0uvx1BbP/AxbY0Z2Al8Zpru6CQexJlQ==")
