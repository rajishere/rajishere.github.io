from AppInfo import AppInfo

appInfo = AppInfo()

