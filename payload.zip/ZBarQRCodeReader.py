#!/usr/bin/python
import zbar
import multiprocessing
from multiprocessing import Queue
import time

class ZBarQRCodeReader(object):
    def __init__(self):
        self.running = True
        
    def zbarWorker(self, queue):
        # create a Processor
        self.proc = zbar.Processor()

        # configure the Processor
        self.proc.parse_config('enable')

        # initialize the Processor
        device = '/dev/video0'
        self.proc.init(device)
        
        # enable the preview window
        self.proc.visible = True

        # initiate scanning
        self.proc.active = True
        try:
            # keep scanning until user provides key/mouse input
            while self.running:
                self.proc.process_one()
                results = []
                for symbol in self.proc.results:
                    # do something useful with results
                    if symbol.type == zbar.Symbol.QRCODE:
                        results.append(symbol.data)
                if len(results) > 0:
                    #print(results[0])
                    queue.put(results[0])
                    time.sleep(1.8)
                #proc.user_wait()
        except Exception as e:
            print(e)
            queue.put('error')
        return

    def zbarReader(self, queue, scanHandler, errorHandler):
        error = False
        while self.running:
            data = queue.get()
            if data == 'error':
                error = True
                break
            else:
                scanHandler(data)
        if error:
            errorHandler()
        
        return
    
    def start(self, successHandler, errorHandler):
        queue = Queue()
        p = multiprocessing.Process(target=self.zbarWorker, args=(queue,))
        p.start()
        
        self.zbarReader(queue, successHandler, errorHandler)
        return
    
    def stop(self):
        self.running = False
        self.proc.active = False
        return