import json
import Constants

class Order:
    def __init__(self, payload, orderValidated, isValidOrder):
        self.data = {
            "order_id": "",
            "store_id": 0,
            "totem_id": "",
            "transaction_amount": 0.0,
            "order_validated": False,
            "is_valid_order": False,
            }
        payloadData = json.loads(payload)
        for x in payloadData:
            if x == "tId":
                self.data["order_id"] = payloadData[x]
            elif x == "sId":
                storeId = 0
                try:
                    storeId = int(payloadData[x])
                except:
                    pass
                self.data["store_id"] = storeId
            elif x == "tAmt":
                self.data["transaction_amount"] = payloadData[x]
        self.data["order_validated"] = orderValidated
        self.data["is_valid_order"] = isValidOrder
        self.data["totem_id"] = Constants.totemId
        self.event = "order_confirmed"
        
    def toJSON(self):
        return json.dumps(self.__dict__)