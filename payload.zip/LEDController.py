from threading import Thread
import time
from neopixel import *
import Constants
from threading import Thread

# Neo Pixel
# LED strip configuration:
LED_COUNT      = 20      # Number of LED pixels.
LED_PIN        = 18      # GPIO pin connected to the pixels (18 uses PWM!).
#LED_PIN        = 10      # GPIO pin connected to the pixels (10 uses SPI /dev/spidev0.0).
LED_FREQ_HZ    = 800000  # LED signal frequency in hertz (usually 800khz)
LED_DMA        = 10      # DMA channel to use for generating signal (try 10)
LED_BRIGHTNESS = 255     # Set to 0 for darkest and 255 for brightest
LED_INVERT     = False   # True to invert the signal (when using NPN transistor level shift)
LED_CHANNEL    = 0       # set to '1' for GPIOs 13, 19, 41, 45 or 53

class LEDController(Thread):

    # Create NeoPixel object with appropriate configuration.
    strip = Adafruit_NeoPixel(LED_COUNT, LED_PIN, LED_FREQ_HZ, LED_DMA, LED_INVERT, LED_BRIGHTNESS, LED_CHANNEL)

    brightnessCounter = 0
    binaryCounter = 0
    # 0 for default, 1 for green, 2 for red
    colorCounter = 0
    colorChangeCounter = 0
    successLoopCount = 3
    errorLoopCount = 9

    def __init__(self):
        global strip
        Thread.__init__(self)
        # Intialize the library (must be called once before other functions).
        self.strip.begin()
        self.running = True

    def run(self):
        global strip
        global brightnessCounter
        global binaryCounter
        global colorCounter
        global colorChangeCounter
        global successLoopCount
        global errorLoopCount
        while self.running:
            # set color and wait times as per color code
            color = Color(Constants.defaultColorR, Constants.defaultColorG, Constants.defaultColorB)
            waitPeriod = 10
            if self.colorCounter == 1:
                color = Color(255, 0, 0)
                waitPeriod = 5
            elif self.colorCounter == 2:
                color = Color(0, 255, 0)
                waitPeriod = 1

            for i in range(self.strip.numPixels()):
                self.strip.setPixelColor(i, color)

            if self.brightnessCounter > 254 and self.binaryCounter == 0:
                self.binaryCounter = 1
            elif self.brightnessCounter < 1 and self.binaryCounter == 1:
                if (self.colorCounter == 1 and self.colorChangeCounter >= (self.successLoopCount - 1)) or (self.colorCounter == 2 and self.colorChangeCounter >= (self.errorLoopCount - 1)):
                    self.resetToDefaults()
                else:
                    if self.colorCounter == 1 or self.colorCounter == 2:
                        self.colorChangeCounter += 1
                    self.binaryCounter = 0

            if self.binaryCounter == 0:
                self.brightnessCounter += 1
            else:
                self.brightnessCounter -= 1


            self.strip.setBrightness(self.brightnessCounter)
            self.strip.show()
            time.sleep(waitPeriod/1000.0)
            #print("cc: %d, brc: %d, bic: %d, ccc: %d, wp: %d",self.colorCounter, self.brightnessCounter, self.binaryCounter, self.colorChangeCounter, waitPeriod)

    def stop(self):
        self.running = False
        self.colorWipe()

    def resetToDefaults(self):
        global brightnessCounter
        global binaryCounter
        global colorCounter
        global colorChangeCounter
        self.brightnessCounter = 0
        self.binaryCounter = 0
        self.colorCounter = 0
        self.colorChangeCounter = 0

    def showSuccess(self):
        print("LEDs success")
        global brightnessCounter
        global binaryCounter
        global colorCounter
        self.brightnessCounter = 0
        self.binaryCounter = 0
        self.colorCounter = 1
        return

    def showError(self):
        print("LEDs error")
        global brightnessCounter
        global binaryCounter
        global colorCounter
        self.brightnessCounter = 0
        self.binaryCounter = 0
        self.colorCounter = 2
        return

    def colorWipe(self):
        global strip
        """Wipe color across display a pixel at a time."""
        color = Color(0,0,0)
        for i in range(self.strip.numPixels()):
            self.strip.setPixelColor(i, color)
            self.strip.show()
            time.sleep(10/1000.0)
