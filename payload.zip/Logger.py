import json
import pickle
from datetime import datetime
import os
import time
import Constants

class Logger:
    def logPayload(self, originalPayload, decodedPayload):
        datestring = datetime.strftime(datetime.now(), '%Y-%m-%d')
        fileName = Constants.appRoot + 'logs/log_'+datestring+'.p'
        if os.path.exists(fileName) == False:
            pickle.dump( [], open( fileName, "wb" ) )
        existingLogs = pickle.load( open( fileName, "rb" ) )
        logData = {
            "originalPayload": originalPayload,
            "decodedPayload": decodedPayload,
            "datetime": int(time.time()),
            "storeId": Constants.storeId
            }
        existingLogs.append(logData)
        #print(existingLogs)
        pickle.dump( existingLogs, open( fileName, "wb" ) )
        return