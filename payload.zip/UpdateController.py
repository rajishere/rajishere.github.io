from AppInfo import AppInfo
import requests, zipfile, StringIO
from packaging import version

class UpdateController(object):
    def __init__(self):
        return

    def hasUpdates(self):
        appInfo = AppInfo()

        url = 'https://rajishere.github.io/info.json'
        response = requests.get(url=url)
        payloadData = response.json()
        presentVersion = version.parse(appInfo.data.version)
        payloadVersion = version.parse(payloadData['version'])

        return payloadVersion > presentVersion

    def downloadPackage(self):
        r = requests.get('https://rajishere.github.io/payload.zip', stream=True)
        z = zipfile.ZipFile(StringIO.StringIO(r.content))
        z.extractall()
        return