import requests, zipfile, StringIO
from packaging import version
import Constants
import shutil
import os

class UpdateController(object):
    def __init__(self):
        return

    def hasUpdates(self):
        url = Constants.updateInfoURL
        response = requests.get(url=url)
        payloadData = response.json()
        presentVersion = version.parse(Constants.version)
        payloadVersion = version.parse(payloadData['version'])

        return payloadVersion > presentVersion

    def downloadPackage(self):
        shutil.rmtree("/home/pi/Documents/scan-and-pay-validation/")
        r = requests.get(Constants.updatePayloadURL, stream=True)
        z = zipfile.ZipFile(StringIO.StringIO(r.content))
        z.extractall("/home/pi/Documents/scan-and-pay-validation/")
        os.chmod("/home/pi/Documents/scan-and-pay-validation/", 0755)
        return