import json
from collections import namedtuple
import Constants

class AppConfigController(object):
    
    def fetchAppConfig(self, successhandler, errorhandler):
        with open(Constants.appRoot + 'LocalAppConfig.json') as f:
            data = f.read()
            self.appConfig = json.loads(data, object_hook=lambda d: namedtuple('X', d.keys())(*d.values()))
            successhandler(self.appConfig)
        return