import os
import sys

if len(sys.argv) > 0 and 'stop' in sys.argv:
    # stop as recieved from command line
    os.system("sudo pkill -9 -f /home/totemadmin/Documents/scan-and-pay-validation/App.py")
else:
    # start the main script
    os.system("sudo /usr/bin/python /home/totemadmin/Documents/scan-and-pay-validation/App.py &")