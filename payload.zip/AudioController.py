import pygame
from threading import Thread
import Constants

class AudioController(Thread):
    
    def __init__(self):
        Thread.__init__(self)
        # Intialize the library (must be called once before other functions).
        pygame.mixer.init()
        self.running = True
    
    def run(self):
        while self.running:
            print("")
            
    def stop(self):
        self.running = False
        
    def playSuccess(self):
        pygame.mixer.music.load(Constants.appRoot + "assets/success.wav")
        pygame.mixer.music.play()
        while pygame.mixer.music.get_busy() == True:
            continue
        
    def playError(self):
        pygame.mixer.music.load(Constants.appRoot + "assets/error.wav")
        pygame.mixer.music.play()
        while pygame.mixer.music.get_busy() == True:
            continue